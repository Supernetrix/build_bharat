"use client"

import Avatar from "react-nice-avatar"
import { ShoppingCart, Search, Play, Gamepad2, Trophy, Bell, Menu, Lock } from "lucide-react"
import { useState } from "react"
import { Carousel, CarouselContent, CarouselItem, type CarouselApi } from "@/components/ui/carousel"
import { useRouter } from "next/navigation"

const gameCards = [
    {
        id: 1,
        title: "Tebak Gambar",
        online: "8,472",
        bgTop: "#F7B844",
        bgBottom: "#F95C8A",
        character: "pink",
        level: 1,
        isUnlocked: true,
        isCompleted: true,
        progress: 100,
        stars: 3,
        difficulty: "Easy",
        reward: "50 coins",
    },
    {
        id: 2,
        title: "Word Quest",
        online: "5,231",
        bgTop: "#4ECDC4",
        bgBottom: "#44A08D",
        character: "blue",
        level: 2,
        isUnlocked: true,
        isCompleted: false,
        progress: 65,
        stars: 2,
        difficulty: "Medium",
        reward: "75 coins",
    },
    {
        id: 3,
        title: "Math Hero",
        online: "3,847",
        bgTop: "#A8E6CF",
        bgBottom: "#7FCDCD",
        character: "green",
        level: 3,
        isUnlocked: false,
        isCompleted: false,
        progress: 0,
        stars: 0,
        difficulty: "Hard",
        reward: "100 coins",
    },
    {
        id: 4,
        title: "Color Match",
        online: "6,592",
        bgTop: "#FFB6C1",
        bgBottom: "#FFA07A",
        character: "coral",
        level: 4,
        isUnlocked: false,
        isCompleted: false,
        progress: 0,
        stars: 0,
        difficulty: "Medium",
        reward: "80 coins",
    },
    {
        id: 5,
        title: "Brain Teaser",
        online: "4,156",
        bgTop: "#DDA0DD",
        bgBottom: "#9370DB",
        character: "purple",
        level: 5,
        isUnlocked: false,
        isCompleted: false,
        progress: 0,
        stars: 0,
        difficulty: "Expert",
        reward: "150 coins",
    },
    {
        id: 6,
        title: "Speed Quiz",
        online: "7,823",
        bgTop: "#F0E68C",
        bgBottom: "#DAA520",
        character: "yellow",
        level: 6,
        isUnlocked: false,
        isCompleted: false,
        progress: 0,
        stars: 0,
        difficulty: "Hard",
        reward: "120 coins",
    },
    {
        id: 7,
        title: "Memory Game",
        online: "2,945",
        bgTop: "#87CEEB",
        bgBottom: "#4682B4",
        character: "sky",
        level: 7,
        isUnlocked: false,
        isCompleted: false,
        progress: 0,
        stars: 0,
        difficulty: "Expert",
        reward: "200 coins",
    },
]

const characterColors = {
    pink: "#F95C8A",
    blue: "#4ECDC4",
    green: "#A8E6CF",
    coral: "#FFA07A",
    purple: "#DDA0DD",
    yellow: "#F0E68C",
    sky: "#87CEEB",
}

const difficultyColors = {
    Easy: "#4ADE80",
    Medium: "#F59E0B",
    Hard: "#EF4444",
    Expert: "#8B5CF6",
}

export default function GameDashboard() {
    const router = useRouter()
    const [api, setApi] = useState<CarouselApi>()
    const [current, setCurrent] = useState(0)

    const GameCard = ({ game, isActive }: { game: any; isActive: boolean }) => {
        const handlePlayClick = () => {
            if (game.id === 1 && game.isCompleted) {
                // Navigate to Customer Detective level for level 1 play again
                router.push("/level/customer-detective")
            }
            // Add other level navigation logic here for other games
        }

        return (
            <div className="relative">
                {game.isCompleted && (
                    <div className="absolute -top-2 -right-2 z-20">
                        <div className="relative">
                            <div className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-300 rounded-full animate-ping" />
                        </div>
                    </div>
                )}

                <div
                    className={`rounded-3xl relative overflow-hidden shadow-xl transition-all duration-500 ${
                        game.isUnlocked ? "transform" : ""
                    }`}
                    style={{
                        borderRadius: "24px",
                        height: "360px",
                        width: "300px",
                        filter: game.isUnlocked ? "none" : "grayscale(50%)",
                        backgroundColor: game.bgTop,
                    }}
                >
                    {!game.isUnlocked && (
                        <div className="absolute inset-0 z-30 bg-black/40 rounded-3xl flex items-center justify-center">
                            <div className="bg-white/90 backdrop-blur-sm rounded-full p-4 shadow-lg">
                                <Lock className="w-8 h-8 text-gray-600" />
                            </div>
                        </div>
                    )}

                    <div className="absolute inset-0 opacity-20">
                        <div
                            className="absolute top-4 left-4 w-6 h-6 bg-white/30 rounded-full animate-bounce"
                            style={{ animationDelay: "0s" }}
                        />
                        <div
                            className="absolute top-8 right-6 w-4 h-4 bg-white/20 rounded-full animate-bounce"
                            style={{ animationDelay: "0.5s" }}
                        />
                        <div
                            className="absolute bottom-12 left-8 w-3 h-3 bg-white/25 rounded-full animate-bounce"
                            style={{ animationDelay: "1s" }}
                        />
                    </div>

                    <div className="relative z-20 p-6 flex flex-col h-full justify-between text-center">
                        <div className="bg-white/95 backdrop-blur-sm rounded-2xl px-4 py-2 shadow-lg">
                            <div className="flex items-center justify-center gap-2 mb-1">
                <span className="text-xs font-bold text-gray-500 font-[family-name:var(--font-space-grotesk)]">
                  LEVEL {game.level}
                </span>
                                <div
                                    className="px-2 py-0.5 rounded-full text-xs font-bold text-white"
                                    style={{ backgroundColor: difficultyColors[game.difficulty as keyof typeof difficultyColors] }}
                                >
                                    {game.difficulty}
                                </div>
                            </div>
                            <h2 className="text-lg font-bold text-[#111111] font-[family-name:var(--font-unbounded)] leading-tight">
                                {game.title}
                            </h2>
                        </div>

                        <button
                            onClick={handlePlayClick}
                            className={`relative z-40 w-full rounded-2xl py-4 font-bold text-white flex items-center justify-center gap-2 font-[family-name:var(--font-space-grotesk)]`}
                            style={{
                                backgroundColor: game.isUnlocked ? "#212121" : "#666666",
                                transform: isActive ? "translateY(-2px)" : "translateY(0px)",
                            }}
                            disabled={!game.isUnlocked}
                        >
                            {game.isUnlocked ? (
                                <>
                                    <Play className="w-5 h-5 fill-current" />
                                    <span>{game.isCompleted ? "Play Again" : "Continue"}</span>
                                </>
                            ) : (
                                <>
                                    <Lock className="w-5 h-5" />
                                    <span>Complete Level {game.level - 1}</span>
                                </>
                            )}
                        </button>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <div className="min-h-screen relative overflow-hidden" style={{ backgroundColor: "#F8F7F4" }}>
            <div className="absolute inset-0 opacity-40">
                <svg width="100%" height="100%" viewBox="0 0 400 400" className="absolute inset-0">
                    <defs>
                        <pattern id="celebrationWaves" x="0" y="0" width="200" height="200" patternUnits="userSpaceOnUse">
                            <path d="M0,100 Q50,50 100,100 T200,100 L200,200 L0,200 Z" fill="#F0EFEA" opacity="0.8" />
                            <circle cx="50" cy="75" r="3" fill="#F7B844" opacity="0.6" />
                            <circle cx="150" cy="125" r="2" fill="#F95C8A" opacity="0.5" />
                        </pattern>
                    </defs>
                    <rect width="100%" height="100%" fill="url(#celebrationWaves)" />
                </svg>
            </div>

            <div className="relative z-10 px-4 py-6 max-w-sm mx-auto">
                <div className="flex flex-col gap-4 mb-8">
                    <div className="flex items-center justify-between">
                        <div className="bg-white/95 backdrop-blur-sm rounded-2xl px-4 py-3 shadow-lg flex items-center gap-3">
                            <Avatar
                                style={{ width: "40px", height: "40px" }}
                                sex="man"
                                faceColor="#F9C9B6"
                                earSize="small"
                                eyeStyle="circle"
                                noseStyle="short"
                                mouthStyle="peace"
                                shirtStyle="hoody"
                                glassesStyle="none"
                                hairColor="#724133"
                                hairStyle="normal"
                                hatStyle="none"
                                hatColor="#000"
                                shirtColor="#9287FF"
                                bgColor="transparent"
                            />
                            <span className="font-semibold text-[#111111] font-[family-name:var(--font-space-grotesk)] whitespace-nowrap">
                Peter Haltermy
              </span>
                        </div>

                        <div className="bg-white/80 backdrop-blur-sm rounded-full px-3 py-2 flex items-center gap-2 shadow-sm">
                            <div
                                className="w-6 h-6 rounded-full flex items-center justify-center"
                                style={{ backgroundColor: "#F7B844" }}
                            >
                                <div className="w-3 h-3 bg-yellow-300 rounded-full" />
                            </div>
                            <span className="font-semibold text-[#111111] font-[family-name:var(--font-space-grotesk)]">32,503</span>
                        </div>
                    </div>

                    <div className="flex items-center justify-between">
                        <h1
                            className="text-2xl font-bold text-[#111111] leading-tight font-[family-name:var(--font-unbounded)]"
                            style={{ lineHeight: "1.1" }}
                        >
                            Pick Game To Play
                        </h1>

                        <div className="flex flex-col gap-2">
                            <button className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm border border-[#E0E0E0]">
                                <Search className="w-5 h-5 text-gray-600" />
                            </button>
                            <button className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm border border-[#E0E0E0]">
                                <ShoppingCart className="w-5 h-5 text-gray-600" />
                            </button>
                        </div>
                    </div>
                </div>

                <div className="mb-6">
                    <Carousel
                        setApi={setApi}
                        className="w-full"
                        opts={{
                            align: "center",
                            loop: false,
                        }}
                    >
                        <CarouselContent className="-ml-2 md:-ml-4 gap-4">
                            {gameCards.map((game, index) => (
                                <CarouselItem key={game.id} className="pl-2 md:pl-4 basis-4/5">
                                    <GameCard game={game} isActive={current === index} />
                                </CarouselItem>
                            ))}
                        </CarouselContent>
                    </Carousel>
                </div>

                <div className="flex justify-center gap-3 mb-16">
                    {gameCards.map((game, index) => (
                        <div
                            key={game.id}
                            className="relative transition-all duration-300 cursor-pointer"
                            onClick={() => api?.scrollTo(index)}
                        >
                            <div
                                className={`h-3 rounded-full transition-all duration-300 ${index === current ? "w-8" : "w-3"}`}
                                style={{
                                    backgroundColor: game.isCompleted ? "#4ADE80" : game.isUnlocked ? "#212121" : "#D1D5DB",
                                }}
                            />
                        </div>
                    ))}
                </div>

                <div className="fixed bottom-4 left-1/2 -translate-x-1/2 w-80 max-w-[calc(100vw-2rem)]">
                    <div
                        className="rounded-full px-6 py-3 shadow-lg"
                        style={{ backgroundColor: "#1A1A1A", borderRadius: "999px" }}
                    >
                        <div className="flex items-center justify-between">
                            <div className="rounded-full px-4 py-2 flex items-center gap-2" style={{ backgroundColor: "#25D366" }}>
                                <Gamepad2 className="w-5 h-5 text-white" />
                                <span className="text-white font-medium text-sm font-[family-name:var(--font-space-grotesk)]">
                  My Games
                </span>
                            </div>

                            <button
                                className="w-10 h-10 rounded-full flex items-center justify-center"
                                onClick={() => router.push("/leaderboard")}
                            >
                                <Trophy className="w-5 h-5" style={{ color: "#A0A0A0" }} />
                            </button>

                            <button className="w-10 h-10 rounded-full flex items-center justify-center">
                                <Bell className="w-5 h-5" style={{ color: "#A0A0A0" }} />
                            </button>

                            <button className="w-10 h-10 rounded-full flex items-center justify-center">
                                <Menu className="w-5 h-5" style={{ color: "#A0A0A0" }} />
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
