"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { useRouter } from "next/navigation"

interface OnboardingStep {
  id: number
  question: string
  placeholder: string
  type: "textarea" | "select"
  options?: string[]
}

const onboardingSteps: OnboardingStep[] = [
  {
    id: 1,
    question: "Write a brief about your business idea",
    placeholder: "Describe your innovative business concept here...",
    type: "textarea",
  },
  {
    id: 2,
    question: "Which industry does your idea belong to?",
    placeholder: "Select your industry or write a custom one...",
    type: "textarea",
  },
  {
    id: 3,
    question: "Tell us a little about yourself",
    placeholder: "Share your background and experience...",
    type: "textarea",
  },
]

export function OnboardingForm() {
  const [currentStep, setCurrentStep] = useState(1)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const router = useRouter()

  const handleAnswerChange = (stepId: number, value: string) => {
    setAnswers((prev) => ({ ...prev, [stepId]: value }))
  }

  const handleProceed = () => {
    if (currentStep < onboardingSteps.length) {
      setCurrentStep(currentStep + 1)
    } else {
      console.log("Onboarding completed:", answers)
      router.push("/quiz")
    }
  }

  const currentStepData = onboardingSteps.find((step) => step.id === currentStep)
  const progress = (currentStep / onboardingSteps.length) * 100

  return (
    <div className="min-h-screen bg-[color:var(--color-fantasy-bg)] relative overflow-hidden">
      {/* Playful accent shapes */}
      <div className="accent-shape w-16 h-16 bg-[color:var(--color-malibu)] top-20 left-8"></div>
      <div className="accent-shape w-12 h-12 bg-[color:var(--color-blossom-pink)] top-32 right-12"></div>
      <div className="accent-shape w-20 h-20 bg-[color:var(--color-bright-lavender)] bottom-40 left-16"></div>
      <div className="accent-shape w-14 h-14 bg-[color:var(--color-light-coral)] bottom-20 right-20"></div>
      <div className="accent-shape w-10 h-10 bg-[color:var(--color-malibu)] top-1/2 left-4"></div>
      <div className="accent-shape w-18 h-18 bg-[color:var(--color-blossom-pink)] top-1/3 right-8"></div>

      {/* Abstract pattern overlay */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-transparent via-white/20 to-transparent"></div>
      </div>

      <div className="relative z-10 px-6 py-8">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-center mb-4">
            <div className="flex space-x-2">
              {onboardingSteps.map((step) => (
                <div
                  key={step.id}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    step.id <= currentStep ? "bg-[color:var(--color-smoky-black)]" : "bg-gray-300"
                  }`}
                />
              ))}
            </div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 max-w-xs mx-auto">
            <div
              className="bg-[color:var(--color-smoky-black)] h-2 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Question Card */}
        <div className="max-w-md mx-auto">
          {currentStepData && (
            <div className="animate-slide-up">
              {/* Question */}
              <h1 className="text-2xl font-bold text-[color:var(--color-smoky-black)] mb-8 text-center leading-tight">
                {currentStepData.question}
              </h1>

              {/* Input Card */}
              <Card className="bg-[color:var(--color-light-gold)] border-0 rounded-3xl p-6 shadow-lg mb-6 animate-bounce-in">
                <Textarea
                  placeholder={currentStepData.placeholder}
                  value={answers[currentStep] || ""}
                  onChange={(e) => handleAnswerChange(currentStep, e.target.value)}
                  className="min-h-[200px] bg-transparent border-0 text-[color:var(--color-smoky-black)] placeholder:text-[color:var(--color-smoky-black)]/60 text-lg resize-none focus:ring-0 focus:outline-none"
                  style={{ boxShadow: "none" }}
                />

                {/* Proceed Button */}
                <div className="mt-6">
                  <Button
                    onClick={handleProceed}
                    disabled={!answers[currentStep]?.trim()}
                    className="w-full h-14 bg-[color:var(--color-smoky-black)] hover:bg-[color:var(--color-smoky-black)]/90 text-white text-lg font-bold rounded-2xl transition-all duration-200 transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                  >
                    {currentStep === onboardingSteps.length ? "Complete" : "Proceed"}
                  </Button>
                </div>
              </Card>

              {/* Step indicator */}
              <div className="text-center">
                <span className="text-[color:var(--color-smoky-black)]/60 text-sm">
                  Step {currentStep} of {onboardingSteps.length}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
