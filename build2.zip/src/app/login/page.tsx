import { RobotMascot } from "@/components/robot-mascot"
import { LoginForm } from "@/components/login-form"

export default function LoginPage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-[color:var(--color-robot-soft-bg)] via-white to-purple-50 flex items-center justify-center px-6">
      <div className="container mx-auto max-w-4xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="flex justify-center order-2 lg:order-1">
            <RobotMascot />
          </div>
          <div className="flex justify-center order-1 lg:order-2">
            <LoginForm />
          </div>
        </div>
      </div>
    </main>
  )
}
