"use client"

import { useRouter } from "next/navigation"

export default function ExploreJourneyPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFDA57] to-[#F47575] relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-32 h-32 bg-white/10 rounded-full animate-pulse"></div>
        <div className="absolute top-40 right-8 w-24 h-24 bg-white/10 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute bottom-32 left-6 w-40 h-40 bg-white/10 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-20 right-12 w-28 h-28 bg-white/10 rounded-full animate-pulse delay-1500"></div>
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-6 text-center">
        <div className="w-40 h-40 bg-white rounded-full flex items-center justify-center text-8xl mb-8 shadow-2xl animate-bounce">
          🚀
        </div>

        <h1 className="text-4xl font-bold text-white mb-4 text-balance">Ready to Explore Your Journey?</h1>

        <p className="text-white/90 text-lg mb-8 max-w-md text-balance leading-relaxed">
          Your personality profile is complete! Time to discover amazing opportunities and connect with your community.
        </p>

        <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-6 mb-8 max-w-sm w-full">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-white">5</div>
              <div className="text-white/80 text-sm">Matches</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-white">92%</div>
              <div className="text-white/80 text-sm">Compatibility</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-white">3</div>
              <div className="text-white/80 text-sm">Interests</div>
            </div>
          </div>
        </div>

        <div className="space-y-4 w-full max-w-sm">
          <button
            onClick={() => router.push("/dashboard")}
            className="w-full py-4 bg-white text-[#100F06] rounded-2xl font-bold text-lg shadow-lg hover:bg-gray-50 transition-colors"
          >
            Start Your Journey
          </button>

         
        </div>

        <div className="mt-8 text-white/70 text-sm">✨ You're now part of a community of creative innovators!</div>
      </div>
    </div>
  )
}
