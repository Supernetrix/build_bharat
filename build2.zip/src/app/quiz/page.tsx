import { PsychologicalQuiz } from "@/components/psychological-quiz"

export default function QuizPage() {
  return <PsychologicalQuiz />
}
