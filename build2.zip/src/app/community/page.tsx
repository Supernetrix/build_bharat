import CommunityPage from '@/components/CommunityPage'
import React from 'react'

const page = () => {
  return (
    <>
        <CommunityPage />
    </>
  )
}

export default page