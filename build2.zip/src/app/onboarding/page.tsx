import { OnboardingForm } from "@/components/onboarding-form"

export default function OnboardingPage() {
  return <OnboardingForm />
}
