import { Navigation } from "@/components/navigation"
import { RobotMascot } from "@/components/robot-mascot"
import { LoginForm } from "@/components/login-form"
import { HeroSection } from "@/components/hero-section"
import { FeaturesGrid } from "@/components/features-grid"

export default function HomePage() {
    return (
        <main className="min-h-screen bg-gradient-to-br from-[color:var(--color-robot-soft-bg)] via-white to-purple-50">
            <Navigation />

            {/* Login Section */}
            <section className="min-h-screen flex items-center justify-center px-6 pt-20">
                <div className="container mx-auto max-w-6xl">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                        <div className="flex justify-center">
                            <RobotMascot />
                        </div>
                        <div className="flex justify-center">
                            <LoginForm />
                        </div>
                    </div>
                </div>
            </section>

            {/* Hero Section */}
            <HeroSection />

            {/* Features Section */}
            <FeaturesGrid />

            {/* Footer */}
            <footer className="py-12 px-6 bg-black text-white">
                <div className="container mx-auto text-center">
                    <div className="flex items-center justify-center space-x-2 mb-4">
                        <div className="w-8 h-8 bg-[color:var(--color-robot-gold)] rounded-lg flex items-center justify-center">
                            <div className="w-4 h-4 bg-black rounded-sm"></div>
                        </div>
                        <span className="text-2xl font-bold">RoboApp</span>
                    </div>
                    <p className="text-gray-400">Dedicated to Creativity, Culture & Growth.</p>
                </div>
            </footer>
        </main>
    )
}
